#include<iostream>
using namespace std;
int main()
{
    int Length;
    cout << "Enter Length: ";
    cin >> Length;

    int Width;
    cout << "Enter Width: ";
    cin >> Width;

    int Height;
    cout << "Enter Height: ";
    cin >> Height;

    double Volume = (Length * Width * Height);

    cout << "Volume is : " << Volume;

    return 0;
}