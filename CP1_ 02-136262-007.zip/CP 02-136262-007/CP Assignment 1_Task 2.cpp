#include <iostream>
using namespace std;

int main()
{
    string Name;
    int Age;
    char Grade;
    float CGPA;

    cout << "Enter Name: ";
    cin >> Name;

    cout << "Enter Age: ";
    cin >> Age;

    cout << "Enter Grade: ";
    cin >> Grade;

    cout << "Enter CGPA: ";
    cin >> CGPA;

    cout << "STUDENT RECORD:  " << endl;
    cout << "Name is: " << Name << endl;
    cout << "Age is: " << Age << endl;
    cout << "Grade is: " << Grade << endl;
    cout << "CGPA is: " << CGPA << endl;

    return 0;
}