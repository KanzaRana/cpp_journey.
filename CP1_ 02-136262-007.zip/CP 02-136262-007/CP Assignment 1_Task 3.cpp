#include<iostream>
using namespace std;
int main()
{
    int Grade1;
    cout << "Enter Grade1: ";
    cin >> Grade1;

    int Grade2;
    cout << "Enter Grade2: ";
    cin >> Grade2;

    int Grade3;
    cout << "Enter Grade3: ";
    cin >> Grade3;

    double Average = (Grade1 + Grade2 + Grade3) / 3;

    cout << "Average is : " << Average;

    return 0;
}