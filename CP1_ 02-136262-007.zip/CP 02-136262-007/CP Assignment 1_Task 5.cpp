#include<iostream>
using namespace std;
int main()
{
    int Salary;
    cout << "Enter your Salary: ";
    cin >> Salary;

    if (Salary == 200000)
    {
        cout << "designation is Manager";
    }

    else if (Salary == 150000)
    {
        cout << "designation is Supervisor";
    }

    else if (Salary == 80000)
    {
        cout << "designation is Technician";
    }

    else;
    {
        cout << "designation not found ";
    }
    

    return 0;
}